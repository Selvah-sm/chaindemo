package com.sailors.simplechain;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class LinkedList {
    static class Node{
        String data;
        Node next;
        Node(String d){
            data = d;
            next = null;
        }
    }
    Node head;

    public static String getSHA(String input){
        try{
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] messageDigest = md.digest(input.getBytes());
            BigInteger no = new BigInteger(1, messageDigest);
            String hashtext = no.toString(16);
            while(hashtext.length()<32){
                hashtext = "0" + hashtext;
            }
            return hashtext;
        }
        catch (NoSuchAlgorithmException e){
            System.out.println("Exception Thrown: " + e);
        }
        return null;
    }

    // inserting a new node
    public static LinkedList insert(LinkedList list, String data){
        String input = getSHA(data);
        Node new_node = new Node(input);
        if(list.head == null){
            list.head = new_node;
        }
        else{
            Node last = list.head;
            while(last.next != null){
                last = last.next;
            }
            last.next  = new_node;
        }
        return list;
    }

    public static void printList(LinkedList list){
        Node currentNode = list.head;
        while(currentNode != null){
            System.out.println(currentNode.data);
            currentNode = currentNode.next;
        }
    }
}
