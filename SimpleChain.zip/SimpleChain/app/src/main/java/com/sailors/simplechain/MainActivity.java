package com.sailors.simplechain;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.*;

public class MainActivity extends AppCompatActivity {
    LinkedList list = new LinkedList();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnLog = (Button) findViewById(R.id.btnLog);

        btnLog.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick (View v){
                EditText txtlog= (EditText) findViewById(R.id.txtLog);
                QueueService(txtlog.toString());
                list = LinkedList.insert(list, txtlog.getText().toString());
                LinkedList.printList(list);
                Toast.makeText(MainActivity.this, txtlog.getText().toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    private static void QueueService(String data){
        final AmazonSQS sqs = AmazonSQSClientBuilder.defaultClient();
        final String queueURL = "https://sqs.us-east-1.amazonaws.com/253928775046/Sailors";
        sqs.sendMessage(new SendMessageRequest(queueURL,
                "This is my message text."));
    }
}
